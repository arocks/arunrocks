<?php
/*
Plugin Name: Category Livemarks
Plugin URI: http://www.arunrocks.com/blog/
Description: When you click on the RSS icon in the status bar of Firefox, it automatically "discovers" some feeds for you. Would you like to see every category of your blog appear as a seperate feed in Firefox? If so activate this plugin.
Author: Arun Ravindran
Version: 0.5
Author URI: http://www.arunrocks.com/
*/ 

$add_comment_feed = 1;

function show_category_feeds($categories = NULL) {
  global $wpdb;
  $title = get_bloginfo('name');
  if($categories == NULL) {
    $sort_column = 'cat_ID';
    $query  = "
		SELECT cat_ID, cat_name, category_nicename, category_description, category_parent
		FROM $wpdb->categories
		WHERE cat_ID > 0
		ORDER BY cat_ID asc";
    $categories = $wpdb->get_results($query);
  }
  // $categories = get_the_category();
  $catsnum = count($categories);
  foreach ($categories as $category) {
    $link = '     <link rel="alternate" type="application/atom+xml" title="';
    $link = $link . $title . ' Category: ' . $category->cat_name;
    $link = $link . '" href="' . get_category_rss_link(0, $category->cat_ID, $category->category_nicename) . '" />';
    echo $link . "\n";
  }
} 

// Now we set that function up to execute when the admin_footer action is called
add_action('wp_head', 'livemark_index');
add_filter('the_content', 'livemark_filter', 5);

// We need some CSS to position the paragraph
function livemark_index() {
  global $add_comment_feed;
  if($add_comment_feed)
    echo livemark_comments();
  if(is_home()) {
    show_category_feeds();
  }
}

function livemark_comments()
{
  $title = get_bloginfo('name');
  $link = '     <link rel="alternate" type="application/atom+xml" title="';
  $link = $link . $title . ' Comments';
  $link = $link . '" href="' . get_bloginfo('comments_rss2_url') . '" />';
  return $link;
}

function livemark_filter($content)
{
  static $appeared = 0;
  if($appeared == 0) {
    $appeared++; // We are ignoring all posts after the first
    if(!is_home()) {
      show_category_feeds(get_the_category());
    }
  }
  return $content;
}

?>